// The Invisible shader:
float getProceduralColors(inout vec3 diffuse, inout vec3 specular, inout float shininess) {    
    discard;
    return 1.0;
}
